#include <stdio.h>

int main(){
    int withdraw;
    int amount = 50000;
    scanf("&d", &withdraw);
    amount = amount-withdraw;
    prrintf("The amount is:%dshs \n");
    return 0;
}